/**
 * 
 */
/**
 * @author david.kittle
 *
 */
module GeometryCalculator_dkittle {
}