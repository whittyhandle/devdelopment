package edu.cvtc.java;

public class ShiftSupervisor {

}
