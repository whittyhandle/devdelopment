/**
 * 
 */
package edu.cvtc.java;

/**
 * @author david.kittle
 *
 */
public class ProductionWorker {

}
