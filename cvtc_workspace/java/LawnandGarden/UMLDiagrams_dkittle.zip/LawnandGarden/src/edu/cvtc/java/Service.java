/**
 * 
 */
package edu.cvtc.java;

/**
 * @author david.kittle
 *
 */
public class Service {
	
	// Attributes 
	private String serviceName; 
	private String serviceDescription;
	private double serviceCost;
	
	// Default Constructor 
	public Service () {
		this.serviceName = "";
		this.serviceDescription = ""; 
		this.serviceCost = 0.0; 
	}
	
	//Methods Getters and Setters 
	public String getServiceName() {
		return this.serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName; 
	}
	
	public String getServiceDescription() {
		return this.serviceName; 
	}
	
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription; 
	
	}
	
	public double getServiceCost() {
		return this.serviceCost;
	}
	
	public void setServiceCost(double serviceCost) {
		this.serviceCost = serviceCost; 
	}
	
	

}
